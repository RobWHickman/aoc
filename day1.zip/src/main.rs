use std::env;
use std::fs::File;
use std::io::{self, BufRead};
use std::path::Path;
extern crate regex;
use regex::Regex;

static DIGITS: [&'static str; 9] = [
    "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
];

fn main() -> io::Result<()> {
    //expects cargo run path/to/file.txt
    let args: Vec<String> = env::args().collect();

    let file_path = &args[1];
    let lines = read_input(file_path)?;
    let answer: i32 = lines.iter().sum();

    println!("Total Sum: {}", answer);

    Ok(())
}

fn read_input<P: AsRef<Path>>(file_path: P) -> io::Result<Vec<i32>> {
    let file = File::open(file_path)?;
    let reader = io::BufReader::new(file);

    let mut lines = Vec::new();
    for line_result in reader.lines() {
        let line = line_result?;
        let replaced_line = replace_number_words(&line);
        let digits = extract_firstlast_nums(&replaced_line);
        lines.push(digits);
    }

    Ok(lines)
}

fn extract_firstlast_nums(line: &str) -> i32 {
    let digits: Vec<char> = line.chars().filter(|c| c.is_digit(10)).collect();

    let first_digit = digits[0].to_digit(10).unwrap() as i32;
    let last_digit = digits.last().unwrap().to_digit(10).unwrap() as i32;

    first_digit * 10 + last_digit
}

fn replace_number_words(input: &str) -> String {
    let mut output = String::new();

    for c in input.chars() {
        output.push(c);

        for (i, word) in DIGITS.iter().enumerate() {
            let regex = Regex::new(word).unwrap();
            output = regex
                .replace_all(&output, format!("{}{}", i + 1, &word[1..]))
                .to_string();
        }
    }

    output
}
