use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use std::path::Path;
extern crate regex;
use regex::Regex;

fn main() -> io::Result<()> {
    //expects cargo run path/to/file.txt
    let args: Vec<String> = env::args().collect();

    let file_path = &args[1];
    let lines = read_input(file_path)?;

    let game_no = &args[2];

    let mut possible_games = Vec::new();
    let mut game_power = Vec::new();
    for (i, line) in lines.iter().enumerate() {
        let max_blues = get_colour_max(&line, "blue");
        let max_reds = get_colour_max(&line, "red");
        let max_greens = get_colour_max(&line, "green");

        if game_no.parse() == Ok(1) {
            let blues = 14;
            let reds = 12;
            let greens = 13;

            if max_blues <= blues && max_reds <= reds && max_greens <= greens {
                possible_games.push(i + 1);
            }
        } else if game_no.parse() == Ok(2) {
            println!("{}", max_blues * max_greens * max_reds);
            game_power.push(max_blues * max_greens * max_reds);
        }
    }

    if game_no.parse() == Ok(1) {
        let answer: i32 = possible_games.iter().map(|&num| num as i32).sum();
        println!("Total Sum: {}", answer);
        return Ok(());
    } else if game_no.parse() == Ok(2) {
        let answer: i32 = game_power.iter().map(|&num| num as i32).sum();
        println!("Total Sum: {}", answer);
    }
    Ok(())
}

fn read_input<P: AsRef<Path>>(file_path: P) -> io::Result<Vec<String>> {
    let file = File::open(file_path)?;
    let reader = BufReader::new(file);

    let mut lines = Vec::new();
    for line_result in reader.lines() {
        let line = line_result?;
        lines.push(line);
    }

    Ok(lines)
}

fn get_colour_max(input: &str, colour: &str) -> i32 {
    let re = Regex::new(r"^Game [0-9]*: ").unwrap();
    let sets: &str = &re.replace(&input, "").to_string();

    let pattern = format!(r"([0-9]+) {}", colour);
    let re2 = Regex::new(&pattern).unwrap();

    let mut numbers = Vec::new();

    for set in sets.split("; ") {
        for cap in re2.captures_iter(set) {
            if let Some(matched) = cap.get(1) {
                numbers.push(matched.as_str().to_string());
            }
        }
    }

    let max_number = numbers
        .iter()
        .filter_map(|s| s.parse::<i32>().ok())
        .max()
        .unwrap_or(0);

    max_number
}
